#!/usr/bin/env python
# coding=utf-8

from flask import Flask
from flask import render_template
from flask import request

from  matplotlib import pyplot as plt
from PIL import Image
import numpy as np
import os
import six.moves.urllib as urllib
import sys
import tarfile
import tensorflow as tf
import zipfile
import shutil
from scipy import misc

from collections import defaultdict
from io import StringIO

sys.path.append("..")
from utils import label_map_util
from utils import visualization_utils as vis_util


app = Flask(__name__)

def return_img_stream(img_local_path):
    import base64
    img_stream = ''
    with open(img_local_path, 'r') as img_f:
        img_stream = img_f.read()
        img_stream = base64.b64encode(img_stream)
    return img_stream

@app.route('/')
def index():
    img_path = '/home/ubuntu/cyclone/miscellaneous_test/tensorflow/models/research/object_detection/test_images/image2.jpg'
    img_stream = return_img_stream(img_path)
    return render_template('index.html')#filename_img='image2.jpg'

@app.route('/upload', methods=["POST"])
def upload():
    for upload in request.files.getlist("file"):
        print request.files.getlist("file")
        #destination = '/home/ubuntu/jiaying/tensorflow/models/research/object_detection/test_images/image2.jpg'
        #destination = '/home/ubuntu/jiaying/tensorflow/models/research/object_detection/static/image.jpg'
        destination = '/home/ubuntu/cyclone/miscellaneous_test/tensorflow/models/research/object_detection/test_images/image2.jpg'
        upload.save(destination)
    
    MODEL_NAME = 'faster_rcnn_nas_coco_2017_11_08'
    MODEL_FILE = MODEL_NAME + '.tar.gz'
    PATH_TO_CKPT = MODEL_NAME + '/frozen_inference_graph.pb'
    PATH_TO_LABELS = os.path.join('data', 'pet_label_map.pbtxt')
    NUM_CLASSES = 555

    #MODEL_NAME = 'ssd_mobilenet_v1_coco_2017_11_17'
    #MODEL_FILE = MODEL_NAME + '.tar.gz'
    #PATH_TO_CKPT = MODEL_NAME + '/frozen_inference_graph.pb'
    #PATH_TO_LABELS = os.path.join('data', 'mscoco_label_map.pbtxt')
    #NUM_CLASSES = 90

    detection_graph = tf.Graph()
    with detection_graph.as_default():
        od_graph_def = tf.GraphDef()
        with tf.gfile.GFile(PATH_TO_CKPT, 'rb') as fid:
            serialized_graph = fid.read()
            od_graph_def.ParseFromString(serialized_graph)
            tf.import_graph_def(od_graph_def, name='')

    label_map = label_map_util.load_labelmap(PATH_TO_LABELS)
    categories = label_map_util.convert_label_map_to_categories(label_map, max_num_classes=NUM_CLASSES, use_display_name=True)
    category_index = label_map_util.create_category_index(categories)

    def load_image_into_numpy_array(image):
        (im_width, im_height) = image.size
        return np.array(image.getdata()).reshape(
            (im_height, im_width, 3)).astype(np.uint8)

    TEST_IMAGE_PATHS = destination
    IMAGE_SIZE = (48, 32)#12,8

    with detection_graph.as_default():
        with tf.Session(graph=detection_graph) as sess:
            # Definite input and output Tensors for detection_graph
            image_tensor = detection_graph.get_tensor_by_name('image_tensor:0')
            # Each box represents a part of the image where a particular object was detected.
            detection_boxes = detection_graph.get_tensor_by_name('detection_boxes:0')
            # Each score represent how level of confidence for each of the objects.
            # Score is shown on the result image, together with the class label.
            detection_scores = detection_graph.get_tensor_by_name('detection_scores:0')
            detection_classes = detection_graph.get_tensor_by_name('detection_classes:0')
            num_detections = detection_graph.get_tensor_by_name('num_detections:0')
            #for image_path in TEST_IMAGE_PATHS:
            image = Image.open(destination)#image_path
            # the array based representation of the image will be used later in order to prepare the
            # result image with boxes and labels on it.
            image_np = load_image_into_numpy_array(image)
            # Expand dimensions since the model expects images to have shape: [1, None, None, 3]
            image_np_expanded = np.expand_dims(image_np, axis=0)
            # Actual detection.
            (boxes, scores, classes, num) = sess.run(
                [detection_boxes, detection_scores, detection_classes, num_detections],
                feed_dict={image_tensor: image_np_expanded})
            scores2 = scores.copy();

            scores2[0][1:10] = 0;
            if scores[0][0] <= 0.5:
                print "Please check your picture, we cannot detect"
                scores2[0][0] = 0.51
            # Visualization of the results of a detection.
            vis_util.visualize_boxes_and_labels_on_image_array(
                image_np,
                np.squeeze(boxes),
                np.squeeze(classes).astype(np.int32),
                np.squeeze(scores2),
                category_index,
                use_normalized_coordinates=True,
                line_thickness=8)
            plt.figure(figsize=IMAGE_SIZE)
            plt.imshow(image_np)
            plt.savefig('/home/ubuntu/cyclone/miscellaneous_test/tensorflow/models/research/object_detection/static/tutorial.png', format='png')
            x = category_index[classes[0][0]]['name']
            y = str(x)
            print str(category_index[classes[0][0]]['name'])
            print scores[0][0]
            print str(category_index[classes[0][1]]['name'])
            print scores[0][1]
            print str(category_index[classes[0][2]]['name'])
            print scores[0][2]
            strs = "1."+ str(category_index[classes[0][0]]['name']) + " "+str(scores[0][0]) + "<br> " + "2."+ str(category_index[classes[0][1]]['name']) + " "+str(scores[0][1]) + "<br> " + "3."+ str(category_index[classes[0][2]]['name']) + " "+str(scores[0][2]) + " " 
            print strs
            candidate1 = str(category_index[classes[0][0]]['name']) + " "+str(scores[0][0])
            candidate2 = str(category_index[classes[0][1]]['name']) + " "+str(scores[0][1])
            candidate3 = str(category_index[classes[0][2]]['name']) + " "+str(scores[0][2])


            #img_path = '/home/ubuntu/jiaying/tensorflow/models/research/object_detection/tutorial.png'
            #img_path = '/home/ubuntu/jiaying/tensorflow/models/research/object_detection/test_images/image2.jpg'
            img_path = 'tutorial.png'
            #img_stream = return_img_stream(img_path)
    return render_template('index.html',filename_img=img_path, string_variable1=candidate1, string_variable2=candidate2, string_variable3=candidate3)#img_stream=img_stream)

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=5000)
