<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=7" />
<title>Welcome to website-Bird Classification  Team member:  Qi Lyu, Jiaying Yang, Yixiao Qu </title>
<meta content="" name="keywords" />
<meta content="" name="description" />
<link href="base/templates/css/common.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="base/js/base.js"></script>
<script type="text/javascript" src="base/js/common.js"></script>
<script type="text/javascript" src="base/js/form.js"></script>
<script type="text/javascript" src="base/js/blockui.js"></script>
<!-reload-!>
</head>
<body style='background:transparent url(effect/source/bg/bg.jpg) repeat scroll 0% 0%'>
<script>
var PDV_PAGEID='1'; 
var PDV_RP=''; 
var PDV_COLTYPE='index'; 
var PDV_PAGENAME='index'; 
</script>

<div id='contain' style='width:1002px;background:url(effect/source/bg/ibg.png);margin:0px auto;padding:0px'>

<div id='top' style='width:1002px;height:490px;background:none 0% 0% repeat scroll transparent'>


<!-- 头部自定义效果图 -->

<div id='pdv_17716' class='pdv_class'  title='' style='width:1002px;height:176px;top:0px;left:0px; z-index:1'>
<div id='spdv_17716' class='pdv_top' style='overflow:hidden;width:100%;height:100%'>
<div class="pdv_border" style="margin:0;padding:0;height:100%;border:0px  solid;background:;">
	<div style="height:25px;margin:1px;display:none;background:;">
		<div style="float:left;margin-left:12px;line-height:25px;font-weight:bold;color:">
		
		</div>
		<div style="float:right;margin-right:10px;display:none">
		<a href="-1" style="line-height:25px;color:">更多</a>
		</div>
	</div>
<div style="padding:0px">


<img src="diy/pics/20121117/1353133024.gif" border="0" width="100%" />

</div>
</div>

</div>
</div>

<!-- 头部图片轮播 -->

<div id='pdv_16373' class='pdv_class'  title='' style='width:990px;height:261px;top:227px;left:6px; z-index:2'>
<div id='spdv_16373' class='pdv_top' style='overflow:hidden;width:100%;height:100%'>
<div class="pdv_border" style="margin:0;padding:0;height:100%;border:0px  solid;background:;">
	<div style="height:25px;margin:1px;display:none;background:;">
		<div style="float:left;margin-left:12px;line-height:25px;font-weight:bold;color:">
		
		</div>
		<div style="float:right;margin-right:10px;display:none">
		<a href="-1" style="line-height:25px;color:">更多</a>
		</div>
	</div>
<div style="padding:0px">

<link href="http://api.2799.cn/css.php?eGlueW5ldDJ8ODEwNXxhZHZzaGVhZGxifDE1MTI5NTc3MTN8MWEyYjI5OTBjMTVjMTkyNmUyNzNlMDYzYzNjNTY0ZTJ8MkVDRDNGRUE5RDJE" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://api.2799.cn/script.php?eGlueW5ldDJ8ODEwNXxhZHZzaGVhZGxifDE1MTI5NTc3MTN8MWEyYjI5OTBjMTVjMTkyNmUyNzNlMDYzYzNjNTY0ZTJ8MkVDRDNGRUE5RDJE"></script>
<div id='advsheadlb'>

<img src='advs/pics/20120301/1330577342.jpg' border='0' class='advsheadlbpic' id='advsheadlbpic_0'>

<img src='advs/pics/20120301/1330577349.jpg' border='0' class='advsheadlbpic' id='advsheadlbpic_1'>

<img src='advs/pics/20121117/1353136076.jpg' border='0' class='advsheadlbpic' id='advsheadlbpic_2'>

</div>

</div>
</div>

</div>
</div>

<!-- 网站标志 -->

<div id='pdv_14446' class='pdv_class'  title='' style='width:699px;height:77px;top:58px;left:35px; z-index:5'>
<div id='spdv_14446' class='pdv_top' style='overflow:hidden;width:100%;height:100%'>
<div class="pdv_border" style="margin:0;padding:0;height:100%;border:0px  solid;background:;">
	<div style="height:25px;margin:1px;display:none;background:;">
		<div style="float:left;margin-left:12px;line-height:25px;font-weight:bold;color:">
		
		</div>
		<div style="float:right;margin-right:10px;display:none">
		<a href="-1" style="line-height:25px;color:">更多</a>
		</div>
	</div>
<div style="padding:0px">


<a href="#"><img src="advs/pics/20171210/1512889241.png"border="0" /></a>


</div>
</div>

</div>
</div>

<!-- 二级下拉菜单 -->

<div id='pdv_17306' class='pdv_class'   style='width:990px;height:50px;top:176px;left:6px; z-index:9'>
<div id='spdv_17306' class='pdv_top' style='overflow:hidden;width:100%;height:100%'>
<div class="pdv_border" style="margin:0;padding:0;height:100%;border:0px  solid;background:;">
	<div style="height:25px;margin:1px;display:none;background:;">
		<div style="float:left;margin-left:12px;line-height:25px;font-weight:bold;color:">
		导航菜单
		</div>
		<div style="float:right;margin-right:10px;display:none">
		<a href="-1" style="line-height:25px;color:">更多</a>
		</div>
	</div>
<div style="padding:0px">

<link href="http://api.2799.cn/css.php?eGlueW5ldDJ8ODEwNXxkcm9wbWVudXwxNTEyOTU3NzEzfDFhMmIyOTkwYzE1YzE5MjZlMjczZTA2M2MzYzU2NGUyfDJFQ0QzRkVBOUQyRA==" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://api.2799.cn/script.php?eGlueW5ldDJ8ODEwNXxkcm9wbWVudXwxNTEyOTU3NzEzfDFhMmIyOTkwYzE1YzE5MjZlMjczZTA2M2MzYzU2NGUyfDJFQ0QzRkVBOUQyRA=="></script>
<ul id="dropmenu">

<li><a href="index.php">Home</a>

</li>

<li><a href="product/class/">Result</a>

</li>
 
</ul>
<div class="clear"> </div>

</div>
</div>

</div>
</div>
</div>
<div id='content' style='width:1002px;height:494px;background:url(effect/source/bg/cbg.png);margin:0px auto'>


<!-- 自选产品列表 -->

<div id='pdv_14953' class='pdv_class'  title='产品展示' style='width:750px;height:164px;top:328px;left:227px; z-index:6'>
<div id='spdv_14953' class='pdv_content' style='overflow:hidden;width:100%;height:100%'>
<div class="pdv_border" style="margin:0;padding:0;height:100%;border:0px  solid;background:;">
	<div style="height:25px;margin:1px;display:none;background:;">
		<div style="float:left;margin-left:12px;line-height:25px;font-weight:bold;color:">
		产品展示
		</div>
		<div style="float:right;margin-right:10px;display:inline">
		<a href="product/class/" style="line-height:25px;color:">更多</a>
		</div>
	</div>
<div style="padding:0px">

<link href="product/templates/css/productlist_roll.css" type="text/css" rel="stylesheet">
<script src="product/js/productlist_roll.js" type="text/javascript"></script>
<div  class="productlistx">
	<div class="rollproductlists">
		<div class="blkproductlistx">
			<div class="LeftButton" id="LeftArr1"></div>
			<div class="Cont" id="ISL_Cont_11" style="overflow:hidden;">

					<div class="box">
						<div class="fang" style="width:140px;height:110px">
							<div class="picFit" style="width:140px;height:110px">
							<a href="product/html/?14.html" target="_self"><img height="110px" src="product/pics/20171211/1512954291.jpg" width="140px" border="0"></a>
							</div>
						</div>
						<div class="prodtitle"><a href="product/html/?14.html" target="_self" class="prodtitle">trytrytry</a></div>
					</div>
					

					<div class="box">
						<div class="fang" style="width:140px;height:110px">
							<div class="picFit" style="width:140px;height:110px">
							<a href="product/html/?13.html" target="_self"><img height="110px" src="product/pics/20171211/1512954074.jpg" width="140px" border="0"></a>
							</div>
						</div>
						<div class="prodtitle"><a href="product/html/?13.html" target="_self" class="prodtitle">樊刘傻逼</a></div>
					</div>
					

					<div class="box">
						<div class="fang" style="width:140px;height:110px">
							<div class="picFit" style="width:140px;height:110px">
							<a href="product/html/?12.html" target="_self"><img height="110px" src="product/pics/20121114/1352882901.jpg" width="140px" border="0"></a>
							</div>
						</div>
						<div class="prodtitle"><a href="product/html/?12.html" target="_self" class="prodtitle">Product Name</a></div>
					</div>
					

					<div class="box">
						<div class="fang" style="width:140px;height:110px">
							<div class="picFit" style="width:140px;height:110px">
							<a href="product/html/?11.html" target="_self"><img height="110px" src="product/pics/20121114/1352882878.jpg" width="140px" border="0"></a>
							</div>
						</div>
						<div class="prodtitle"><a href="product/html/?11.html" target="_self" class="prodtitle">Product Name</a></div>
					</div>
					

					<div class="box">
						<div class="fang" style="width:140px;height:110px">
							<div class="picFit" style="width:140px;height:110px">
							<a href="product/html/?10.html" target="_self"><img height="110px" src="product/pics/20121114/1352882835.jpg" width="140px" border="0"></a>
							</div>
						</div>
						<div class="prodtitle"><a href="product/html/?10.html" target="_self" class="prodtitle">Product Name</a></div>
					</div>
					

					<div class="box">
						<div class="fang" style="width:140px;height:110px">
							<div class="picFit" style="width:140px;height:110px">
							<a href="product/html/?9.html" target="_self"><img height="110px" src="product/pics/20121114/1352882687.jpg" width="140px" border="0"></a>
							</div>
						</div>
						<div class="prodtitle"><a href="product/html/?9.html" target="_self" class="prodtitle">Product Name</a></div>
					</div>
					

			</div>
			<div class="RightButton" id="RightArr1"></div>
<script language="javascript" type="text/javascript">
<!--//--><![CDATA[//><!--
var scrollPic_03 = new ScrollPic();
scrollPic_03.scrollContId   = "ISL_Cont_11"; //内容容器ID
scrollPic_03.arrLeftId      = "LeftArr1";//左箭头ID
scrollPic_03.arrRightId     = "RightArr1"; //右箭头ID

scrollPic_03.frameWidth     = 727;//显示框宽度
scrollPic_03.pageWidth      = 145; //翻页宽度

scrollPic_03.speed          = 10; //移动速度(单位毫秒，越小越快)
scrollPic_03.space          = 10; //每次移动像素(单位px，越大越快)
scrollPic_03.autoPlay       = true; //自动播放
scrollPic_03.autoPlayTime   = 3; //自动播放间隔时间(秒)

scrollPic_03.initialize(); //初始化
							
		//--><!]]>
</script>
		</div>
	</div>
</div>
<script>
$(function() {
$().picFit("fill");
});
</script>

</div>
</div>

</div>
</div>

<!-- 空白边框 -->

<div id='pdv_15976' class='pdv_class'  title='Result' style='width:759px;height:43px;top:268px;left:235px; z-index:7'>
<div id='spdv_15976' class='pdv_content' style='overflow:hidden;width:100%;height:100%'>
<div class="pdv_border" style="border:0px;height:100%;padding:0;margin:0;">
<div style="height:38px;border:0px;padding:0;margin:0;background:url(base/border/776/images/title.png) repeat-x">
<div style="float:left;font:bold 16px/38px Verdana,microsoft yahei,Arial;padding-left:32px;color:#007013;">
	Result
	</div>
		<div style="float:right;width:60px;height:38px;background:url(base/border/776/images/title.png) -940px 0px no-repeat"><a href="product/class/" style="display:inline;font:10px/38px Verdana,microsoft yahei,Arial;color:#505050;">MORE &gt;&gt;</a></div>
		
</div>

<div style="margin:0px;padding:0px;border:1px #ebebeb solid">
&nbsp;
</div>
</div>

</div>
</div>

<!-- 图片+文字环绕 -->

<div id='pdv_17523' class='pdv_class'  title='ABOUT US' style='width:754px;height:255px;top:0px;left:235px; z-index:8'>
<div id='spdv_17523' class='pdv_content' style='overflow:hidden;width:100%;height:100%'>
<div class="pdv_border" style="border:0px;height:100%;padding:0;margin:0;">
<div style="height:38px;border:0px;padding:0;margin:0;background:url(base/border/776/images/title.png) repeat-x">
<div style="float:left;font:bold 16px/38px Verdana,microsoft yahei,Arial;padding-left:32px;color:#007013;">
	ABOUT US
	</div>
		<div style="float:right;width:60px;height:38px;background:url(base/border/776/images/title.png) -940px 0px no-repeat"><a href="" style="display:none;font:10px/38px Verdana,microsoft yahei,Arial;color:#505050;">MORE &gt;&gt;</a></div>
		
</div>

<div style="margin:0px;padding:0px;border:1px #ebebeb solid">
<div style="float:left;height:102px;width=130;margin:15px 15px 0px 15px">
<a href="http://"><img src="diy/pics/20121114/1352876173.jpg" border="0" width="130" height="102" /></a>
</div>
<div style="font:12px/20px  Verdana,microsoft yahei,Arial;margin:15px 15px 15px 15px;color:#505050;">
Hangzhou Chemical Co., Ltd. specializes Chemical, production and sales of precision connectors. Its products are used in computers, telecom network equipments, industrial apparatuses, ect. The Company is armed with advanced precision mold manufacturing equipment, high-speed hardware pressing equipment, precision plastic injection equipment, automatic assembly line and inspection/testing devices.The company adheres to the business principle of technology plastic injection equipment
</div>

</div>
</div>

</div>
</div>

<!-- 产品分类（列表） -->

<div id='pdv_14950' class='pdv_class'  title='CATEGORY' style='width:210px;height:286px;top:0px;left:6px; z-index:10'>
<div id='spdv_14950' class='pdv_content' style='overflow:hidden;width:100%;height:100%'>
<div class="pdv_border" style="border:0px;height:100%;padding:0;margin:0;">
<div style="height:38px;border:0px;padding:0;margin:0;background:url(base/border/777/images/title.png) repeat-x">
<div style="float:left;font:bold 16px/38px Verdana,microsoft yahei,Arial;padding-left:15px;color:#fff;">
	CATEGORY
	</div>
		<div style="float:right;width:60px;height:38px;margin-right:5px"><a href="-1" style="display:none;font:10px/38px Verdana,microsoft yahei,Arial;color:#fff;">MORE &gt;&gt;</a></div>
</div>

<div style="margin:0px;padding:0px;background:#00791a">

<link href="http://api.2799.cn/css.php?eGlueW5ldDJ8ODEwNHxjbGFzc19lbnwxNTEyOTU3NzEzfDFhMmIyOTkwYzE1YzE5MjZlMjczZTA2M2MzYzU2NGUyfDJFQ0QzRkVBOUQyRA==" rel="stylesheet" type="text/css" />
<div class="class_en">


<a href="product/class/?21.html" target="_self" class="class_en">Mushroom Spawn</a>


<a href="product/class/?2.html" target="_self" class="class_en">Quality potatoes</a>


<a href="product/class/?3.html" target="_self" class="class_en">Fresh Shiitake</a>


<a href="product/class/?4.html" target="_self" class="class_en">Dried Black Fungus</a>


<a href="product/class/?5.html" target="_self" class="class_en">IQF Babty Oyster</a>


<a href="product/class/?20.html" target="_self" class="class_en">Frozen edible</a>


<a href="product/class/?1.html" target="_self" class="class_en">Other food</a>
 
</div>

</div>
</div>

</div>
</div>
</div>
<div id='bottom' style='width:1002px;height:152px;background:none 0% 0% repeat scroll transparent'>


<!-- 图片/FLASH -->

<div id='pdv_14954' class='pdv_class'  title='' style='width:1002px;height:150px;top:0px;left:0px; z-index:3'>
<div id='spdv_14954' class='pdv_bottom' style='overflow:hidden;width:100%;height:100%'>
<div class="pdv_border" style="margin:0;padding:0;height:100%;border:0px  solid;background:;">
	<div style="height:25px;margin:1px;display:none;background:;">
		<div style="float:left;margin-left:12px;line-height:25px;font-weight:bold;color:">
		
		</div>
		<div style="float:right;margin-right:10px;display:none">
		<a href="-1" style="line-height:25px;color:">更多</a>
		</div>
	</div>
<div style="padding:0px">


<img src="diy/pics/20120305/bbg.png" border="0" width="100%" />

</div>
</div>

</div>
</div>

<!-- 底部信息编辑区 -->

<div id='pdv_10807' class='pdv_class'  title='脚注信息' style='width:599px;height:67px;top:22px;left:275px; z-index:4'>
<div id='spdv_10807' class='pdv_bottom' style='overflow:hidden;width:100%;height:100%'>
<div class="pdv_border" style="margin:0;padding:0;height:100%;border:0px  solid;background:;">
	<div style="height:25px;margin:1px;display:none;background:;">
		<div style="float:left;margin-left:12px;line-height:25px;font-weight:bold;color:">
		脚注信息
		</div>
		<div style="float:right;margin-right:10px;display:none">
		<a href="-1" style="line-height:25px;color:">更多</a>
		</div>
	</div>
<div style="padding:0px">
<div style="width:100%;text-align:center;font:12px/20px Arial, Helvetica, sans-serif">
<div style="FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; COLOR: #505050; TEXT-ALIGN: center; MARGIN: 0px; LINE-HEIGHT: 24px">Copyright(C)2017&nbsp; Bird Classification&nbsp; Team member:&nbsp; Qi Lyu, Jiaying Yang, Yixiao Qu </div>
</div>

</div>
</div>

</div>
</div>
</div>
</div><div id='bodyex'>

</div>
<div id='topex' style='display:none;width:100%;height:490px;background:none 0% 0% repeat scroll transparent'>
</div>
<div id='contentex' style='display:none;width:100%;height:494px;background:url(effect/source/bg/cbg.png)'>
</div>
<div id='bottomex' style='display:none;width:100%;height:152px;background:none 0% 0% repeat scroll transparent'>
</div>
<div id='advsex'></div>

</body>
</html>
