
sink("outfile.txt")

for (i in 1:555){
  
  cat("item {")
  cat("\n")
  cat("  id:",i)
  cat("\n")

  cat(paste("  name: '", class[i],"'", sep = ""))
  cat("\n")
  cat("}")
  cat("\n")
  cat("\n")

  

  
}
sink()

#############
sink("outfile.txt")

for (i in 1:555){
  
  cat("item {")
  cat("\n")
  cat("  id:",i)
  cat("\n")
  
  cat("  name:", class[i])
  cat("\n")
  cat("}")
  cat("\n")
  cat("\n")
  
  
  
  
}
sink()

sink("outfile.py")

for (i in 1:555){
  cat(paste("    elif row_label == ", class[i],":", sep = ""))
  cat("\n")
  cat("        return",i)
  cat("\n")
}
sink()


